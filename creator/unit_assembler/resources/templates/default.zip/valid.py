from typing import Literal, Union

from pydantic import BaseModel


class BaseSlide(BaseModel):
    title: str
    tip: str | None = None
    uuid: str | None = None

    class Config:
        extra = "ignore"


class TextSlide(BaseSlide):
    type: Literal["text"]
    text: str


class SingleChoiceQuestion(BaseModel):
    question: str
    correct_answer: str
    wrong_answers: list[str]

    class Config:
        extra = "ignore"


class SingleChoiceSlide(BaseSlide):
    type: Literal["single_choice"]
    question_items: list[SingleChoiceQuestion]
    positive_feedback: str
    negative_feedback: str


class DragTextSlide(BaseSlide):
    type: Literal["drag_text"]
    user_instruction: str
    cloze_text: str
    distractors: list[str] | None = None


Slide = Union[TextSlide, SingleChoiceSlide, DragTextSlide]


class Main(BaseModel):
    title: str
    slides: list[Slide]
    bg_color: str | None = None

    class Config:
        extra = "ignore"
