 H5P Single Choice Set
=====================

Allows you to create sets of single choice tasks.

## License

*H5P Single Choice Set* is [MIT licensed](LICENSE.md)
